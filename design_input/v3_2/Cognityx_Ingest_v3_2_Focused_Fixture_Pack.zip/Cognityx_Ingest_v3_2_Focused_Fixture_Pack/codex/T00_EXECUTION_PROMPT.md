# Codex execution prompt — T00 with authoritative v3.2 fixture pack

Work autonomously in `cognityx/cognityx-ingest`. Fetch and rebase from
`origin/main`, create branch `devbb/v3-2-t00-focused-fixtures`, and complete T00 only.

The user will provide `Cognityx_Ingest_v3_2_Focused_Fixture_Pack.zip`.
This ZIP is the authoritative v3.2 delta fixture. Do not redesign it, regenerate its source truth, replace
its expected records with current production output, or create a different v3.2 fixture.

1. Unpack it outside the repository.
2. Run its verifier.
3. Confirm that the existing repository base fixture has the exact SHA-256 required by the pack:

   `tests/fixtures/provenance_v1/main_policy_v2.pdf`

4. Install the delta pack using `install_into_repo.py`.
5. Copy and adapt the supplied test templates into `tests/v3_2/`.
6. Audit existing tests and modules and create `planning/v3_2/EXISTING_ASSET_AND_FIXTURE_AUDIT.md`.
7. Add bounded T01–T10 task specifications, using the supplied focused contract and invariants.
8. Make fixture-integrity and already-supported contract tests pass. Mark genuinely missing production
   behaviour strict xfail against intended production seams.
9. Do not change production parsing behaviour, do not modify `cognityx-sdk`, do not weaken existing tests,
   and do not begin T01.
10. Run `uv sync --extra dev`, `uv run pytest`, `uv run mkdocs build --strict`, and `uv build`.
11. Open one draft PR titled `Freeze v3.2 focused contract and fixture scaffold`, then stop.

The normal CLI remains unchanged. The complete Docling native artifact must remain preservable. The
canonical overlay is additive and parser-neutral. Exactly three capability-source classes and exactly three
adaptive routing modes are fixed by the pack.
