from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def copy_tree(source: Path, target: Path) -> None:
    if target.exists():
        raise SystemExit(f"Refusing to overwrite existing path: {target}")
    shutil.copytree(source, target)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo_root", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    repo = args.repo_root.resolve()
    if not (repo / "pyproject.toml").is_file():
        raise SystemExit(f"Not a repository root: {repo}")

    fixture_target = repo / "tests" / "fixtures" / "v3_2_focused"
    planning_target = repo / "planning" / "v3_2"

    fixture_source = root
    planning_source = root / "planning"

    fixture_target.parent.mkdir(parents=True, exist_ok=True)
    planning_target.parent.mkdir(parents=True, exist_ok=True)

    # Copy fixture material but exclude design/prompt/install-only directories.
    ignored = {"planning", "codex", "design", "test_templates", "install_into_repo.py"}
    fixture_target.mkdir()
    for child in fixture_source.iterdir():
        if child.name in ignored:
            continue
        destination = fixture_target / child.name
        if child.is_dir():
            shutil.copytree(child, destination)
        else:
            shutil.copy2(child, destination)

    copy_tree(planning_source, planning_target)
    print(f"Installed fixture: {fixture_target}")
    print(f"Installed planning: {planning_target}")
    print("Review test_templates/ and copy them into tests/v3_2 only as part of T00.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
