from __future__ import annotations

import pytest


@pytest.mark.xfail(strict=True, reason="T01: real parser-native artifact preservation API not implemented")
def test_real_docling_artifact_is_preserved_losslessly(production_ingest_api):
    result = production_ingest_api.ingest_fixture("provenance_v1/main_policy_v2.pdf", parser="docling")
    native = production_ingest_api.read_native_artifact(result.document_id, "docling")
    reloaded = production_ingest_api.reload_native_artifact(native)
    assert reloaded.sha256 == native.sha256
    assert reloaded.native_document_is_valid is True


@pytest.mark.xfail(strict=True, reason="T03: parser capability registry API not implemented")
def test_runtime_capability_registry_exposes_three_sources(production_ingest_api):
    record = production_ingest_api.parser_capabilities("docling")
    assert set(record.capability_sources) == {
        "parser-discovered", "human-guided", "auto-learned"
    }


@pytest.mark.xfail(strict=True, reason="T06: non-copying segmentation view API not implemented")
def test_runtime_views_reference_canonical_nodes(production_ingest_api):
    view = production_ingest_api.create_view("doc-fixture", strategy="paragraph")
    assert all(segment.text is None for segment in view.segments)
    assert all(segment.node_spans for segment in view.segments)
