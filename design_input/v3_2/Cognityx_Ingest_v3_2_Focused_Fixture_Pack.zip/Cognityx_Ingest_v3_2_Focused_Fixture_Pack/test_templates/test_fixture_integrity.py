from __future__ import annotations

import hashlib
import json
from pathlib import Path

FIXTURE = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_manifest_and_delta_source_hashes() -> None:
    manifest = json.loads((FIXTURE / "fixture_manifest.json").read_text(encoding="utf-8"))
    assert manifest["schema"] == "cognityx.ingest.fixture-manifest/v3.2"
    for item in manifest["synthetic_source_truth"]:
        assert sha256(FIXTURE / item["path"]) == item["sha256"]


def test_exactly_three_capability_sources_and_routing_modes() -> None:
    registry = json.loads((FIXTURE / "capability_registry/parser_capabilities.json").read_text(encoding="utf-8"))
    assert registry["allowed_capability_source_classes"] == [
        "parser-discovered", "human-guided", "auto-learned"
    ]
    assert registry["allowed_routing_modes"] == [
        "deterministic", "hybrid", "llm-directed"
    ]
    for parser in registry["parsers"]:
        assert set(parser["capability_sources"]) == {
            "parser-discovered", "human-guided", "auto-learned"
        }


def test_segmentation_views_do_not_copy_text() -> None:
    views = json.loads((FIXTURE / "segmentation_views/views.json").read_text(encoding="utf-8"))
    forbidden = {"text", "content", "page_text", "chunk_text"}
    for view in views["views"]:
        for segment in view["segments"]:
            assert forbidden.isdisjoint(segment)


def test_unresolved_relation_is_not_gold() -> None:
    graph = json.loads((FIXTURE / "expected/source_graph.json").read_text(encoding="utf-8"))
    unresolved = next(x for x in graph["relations"] if x["relation_id"] == "rel-ambiguous-example")
    assert unresolved["gold_eligible"] is False
    assert unresolved["status"] == "ambiguous"
